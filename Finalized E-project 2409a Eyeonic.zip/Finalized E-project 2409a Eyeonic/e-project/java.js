function showAlert(event) {
    event.preventDefault(); 
    alert("Form submitted successfully!");
}